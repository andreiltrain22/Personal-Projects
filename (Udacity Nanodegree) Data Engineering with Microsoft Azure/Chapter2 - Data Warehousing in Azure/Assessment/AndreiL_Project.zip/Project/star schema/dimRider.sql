--drop Rider table if it exists
BEGIN   
    IF OBJECT_ID('dbo.dimRider') IS NOT NULL
        DROP TABLE dimRider
END    
GO;

--create Rider table structure based on project analytics specifications
CREATE TABLE dimRider (
    RiderId int NOT NULL,
    Birthdate date,
    IsMember bit NOT NULL,
    AccountStartDate date,
    AccountEndDate date
)
GO;

--add primary key constraint
ALTER TABLE dimRider
ADD CONSTRAINT PK_dimRider_RiderId PRIMARY KEY NONCLUSTERED (RiderId) NOT ENFORCED
GO;

--populate Rider table
INSERT INTO dimRider
SELECT 
    try_convert(int, RiderId), --from bigint in stg table to int
    Birthdate,
    IsMember,
    try_convert(date, left(AccountStartDate, 10)), --convert to date format
    try_convert(date, left(AccountEndDate, 10)) --convert to date format
FROM staging_rider
GO;

SELECT TOP 100 *
FROM dimRider
GO;
